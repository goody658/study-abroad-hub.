# Study Abroad Hub — starter project

This project contains a responsive website, university destination links, sample service fees, an enquiry form, optional business contact/bank-transfer details, and server-side Paystack checkout initialization and verification.

## Important limitations before launch
- This is a starter, not a fully production-ready student-management system.
- Enquiry submissions are validated but are NOT stored permanently. Add a secure database, access controls, backups, privacy notice, and data-retention process before collecting real student data.
- Sample service prices are placeholders. They are for Study Abroad Hub's own services, not official university application fees or tuition.
- The school cards link to official information portals rather than claiming specific institutions have approved or partnered with this business.
- Collect tuition for a university only with written authorisation and an approved payment arrangement.
- USD checkout is disabled by default. Enable it only after the payment provider confirms that the account is eligible to accept USD transactions and settle funds in the intended currency. Currency displayed at checkout does not guarantee USD settlement.
- Never put the Paystack secret key in browser code or commit it to GitHub.
- The displayed bank details and agent number are optional public information. Only show a business account that you are authorised to use. For safer card payments, customers should pay through the payment provider rather than sending funds to an unverified account.

## Run locally
1. Install Node.js 18 or later.
2. Copy `.env.example` to `.env`.
3. Set `BASE_URL` to your deployed URL and add your Paystack test secret key to `PAYSTACK_SECRET_KEY`.
4. Run `npm install` and `npm start`.
5. Open `http://localhost:3000`.

## Deploy to Render
- Connect the repository to a Node Web Service.
- Build command: `npm install`
- Start command: `npm start`
- Add environment variables in the host dashboard (do not commit `.env`):
  - `BASE_URL`: your deployed HTTPS URL
  - `PAYSTACK_SECRET_KEY`: start with a test secret key
  - `BUSINESS_BANK_NAME`, `BUSINESS_ACCOUNT_NAME`, `BUSINESS_ACCOUNT_NUMBER`: optional; only if appropriate to display publicly
  - `BUSINESS_AGENT_NUMBER`: optional business contact number
  - `ENABLE_USD_CHECKOUT`: keep `false` until provider approval and end-to-end testing
- Set live keys only after verification and testing. Check current provider requirements directly with Paystack.

## Deploy to Netlify
This project uses a long-running Express/Node server, so uploading the `public` folder alone only publishes the static pages; it does not run `server.js` or the `/api` endpoints. To use Netlify, convert the Express endpoints to Netlify Functions and configure redirects, or host the full app on a Node-compatible host such as Render.

## Edit sample service prices
Edit `programs` in `server.js`, and update the matching service cards/options in `public/index.html`. Amounts are in major currency units; Paystack amounts are converted to minor units by the server.

## Bank / agent details
Enter values in the hosting provider's environment settings, not in public HTML source:
- `BUSINESS_BANK_NAME`
- `BUSINESS_ACCOUNT_NAME`
- `BUSINESS_ACCOUNT_NUMBER`
- `BUSINESS_AGENT_NUMBER`

Anything displayed on the public website can be copied by visitors. Do not publish bank login credentials, PINs, OTPs or secret keys.

const $ = (selector) => document.querySelector(selector);
$("#year").textContent = new Date().getFullYear();

const services = {
  application_review: { label: "Application review", ngn: "₦15,000", usd: "$25" },
  document_guidance: { label: "Document guidance", ngn: "₦25,000", usd: "$40" },
  application_support: { label: "Application support", ngn: "₦50,000", usd: "$80" }
};

document.querySelectorAll(".choose-service").forEach(btn => btn.addEventListener("click", () => {
  $("#service-select").value = btn.dataset.service;
  $("#payment-service").value = btn.dataset.service;
  $("#apply").scrollIntoView({ behavior: "smooth" });
}));

async function loadConfig() {
  try {
    const r = await fetch("/api/config");
    const c = await r.json();
    $("#agent-number").textContent = c.agentNumber || "Add BUSINESS_AGENT_NUMBER in the server environment settings.";
    $("#bank-name").textContent = c.bankName || "Add BUSINESS_BANK_NAME in the server environment settings.";
    $("#account-name").textContent = c.accountName || "Add BUSINESS_ACCOUNT_NAME in the server environment settings.";
    $("#account-number").textContent = c.accountNumber || "Add BUSINESS_ACCOUNT_NUMBER in the server environment settings.";
    const usdOption = [...$("#currency").options].find(o => o.value === "USD");
    if (usdOption && !c.usdEnabled) usdOption.textContent = "US dollars (USD — not enabled yet)";
  } catch (_) {}
}
loadConfig();

$("#application-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const status = $("#application-status");
  status.textContent = "Submitting…";
  const data = Object.fromEntries(new FormData(e.currentTarget).entries());
  try {
    const r = await fetch("/api/applications", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    const result = await r.json();
    status.textContent = result.message || result.error || "Unable to submit.";
    if (result.ok) status.textContent += " Reference: " + result.reference;
  } catch (_) {
    status.textContent = "Could not connect. Please try again later.";
  }
});

$("#payment-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const status = $("#payment-status");
  status.textContent = "Connecting to secure checkout…";
  const data = Object.fromEntries(new FormData(e.currentTarget).entries());
  try {
    const r = await fetch("/api/payments/initialize", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    const result = await r.json();
    if (!r.ok || !result.checkoutUrl) throw new Error(result.error || "Payment setup is not ready.");
    window.location.href = result.checkoutUrl;
  } catch (err) {
    status.textContent = err.message || "Payment could not be started.";
  }
});

require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const path = require("path");

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "50kb" }));
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY || "";
const BASE_URL = (process.env.BASE_URL || "").replace(/\/$/, "");

const programs = {
  application_review: { label: "Application review service", ngn: 15000, usd: 25 },
  document_guidance: { label: "Document guidance service", ngn: 25000, usd: 40 },
  application_support: { label: "Application support service", ngn: 50000, usd: 80 }
};

app.get("/api/config", (_req, res) => {
  res.json({
    businessName: "Study Abroad Hub",
    bankName: process.env.BUSINESS_BANK_NAME || "",
    accountName: process.env.BUSINESS_ACCOUNT_NAME || "",
    accountNumber: process.env.BUSINESS_ACCOUNT_NUMBER || "",
    agentNumber: process.env.BUSINESS_AGENT_NUMBER || "",
    usdEnabled: process.env.ENABLE_USD_CHECKOUT === "true"
  });
});

app.get("/api/programs", (_req, res) => res.json(programs));

app.post("/api/applications", (req, res) => {
  const { fullName, email, phone, country, university, course, level, service } = req.body || {};
  if (![fullName, email, phone, country, university, course, level, service].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({ error: "Please complete all required application fields." });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (!programs[service]) return res.status(400).json({ error: "Choose a valid service." });

  // Starter demo: no database is connected, so the application is validated but not permanently saved.
  // Add a secure database and privacy controls before accepting real student applications.
  const reference = "SAH-" + Date.now().toString(36).toUpperCase();
  res.json({
    ok: true,
    reference,
    message: "Your form passed validation. This starter version does not permanently store applications yet."
  });
});

app.post("/api/payments/initialize", async (req, res) => {
  try {
    if (!PAYSTACK_SECRET_KEY.startsWith("sk_test_") && !PAYSTACK_SECRET_KEY.startsWith("sk_live_")) {
      return res.status(503).json({ error: "Payment setup is incomplete. Configure your Paystack secret key on the server." });
    }
    const { email, service, currency } = req.body || {};
    if (typeof email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({ error: "Enter a valid email address." });
    }
    if (!programs[service]) return res.status(400).json({ error: "Choose a valid service." });
    const curr = String(currency || "NGN").toUpperCase();
    if (!["NGN", "USD"].includes(curr)) return res.status(400).json({ error: "Currency must be NGN or USD." });
    if (curr === "USD" && process.env.ENABLE_USD_CHECKOUT !== "true") {
      return res.status(403).json({ error: "USD checkout is not enabled. Confirm USD payments and settlement with Paystack first." });
    }

    const amountMajor = curr === "NGN" ? programs[service].ngn : programs[service].usd;
    const payload = {
      email,
      amount: Math.round(amountMajor * 100),
      currency: curr,
      callback_url: BASE_URL ? `${BASE_URL}/payment-return.html` : undefined,
      metadata: {
        service,
        service_label: programs[service].label,
        website: "Study Abroad Hub"
      }
    };
    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
    const result = await response.json();
    if (!response.ok || !result.status || !result.data?.authorization_url) {
      return res.status(502).json({ error: result.message || "Payment provider could not initialize checkout." });
    }
    res.json({ ok: true, checkoutUrl: result.data.authorization_url });
  } catch (err) {
    console.error("Payment initialization error:", err.message);
    res.status(500).json({ error: "Could not start payment. Please try again later." });
  }
});

app.get("/api/payments/verify/:reference", async (req, res) => {
  try {
    if (!PAYSTACK_SECRET_KEY) return res.status(503).json({ error: "Payment verification is not configured." });
    const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(req.params.reference)}`, {
      headers: { Authorization: `Bearer ${PAYSTACK_SECRET_KEY}` }
    });
    const result = await response.json();
    if (!response.ok || !result.status) return res.status(502).json({ error: "Could not verify payment." });
    const d = result.data;
    res.json({
      ok: true,
      status: d.status,
      currency: d.currency,
      amount: d.amount / 100,
      reference: d.reference,
      paid: d.status === "success"
    });
  } catch (err) {
    console.error("Payment verification error:", err.message);
    res.status(500).json({ error: "Could not verify payment." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`Study Abroad Hub listening on ${PORT}`));
